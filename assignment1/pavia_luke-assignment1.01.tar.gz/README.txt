Assignment 1.01: Terrain Generation
Luke Pavia

This file generates an 80x21 size terrain for my future Pokemon game. The terrain in my program
includes methods that initally create the map then fills it with regions including water and tallgrass 
and other terrains such as trees and boulders. The map also has two paths one going from north to south
and the other going east to west which the player will be able to walk on in the future. I also have 
Pokecenters and Pokemarts connected to the path currently as 1x1. In the future, I might go back
and make the Pokecenters and Pokemarts 2x2.


