#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
int width = 80;
int height = 21;
#define PATH '#'
#define POKEMON_CENTER 'C'
#define POKEMART 'M'
#define TALL_GRASS ':'
#define WATER '~'
#define CLEARING '.'
#define BOULDER '%'
#define TREE '^'


void initializeMap(char map[height][width]) {
    // Fill borders with boulders and inside with clearings
    for (int row = 0; row < height; row++) {
        for (int col = 0; col < width; col++) {
            // Set boulders at borders
            if (row == 0 || row == height - 1 || col == 0 || col == width - 1) {
                map[row][col] = BOULDER; 
            // Fill inside of map with clearings
            } else {
                map[row][col] = CLEARING; 
            }
        }
    }
}


void createPath(char map[height][width], char path) {
    // Initial position for North to South path
    int nsPathX = rand() % (width - 3) + 2;
    int prevNsPathX = nsPathX;
    int startX;
    int endX;
    int startY;
    int endY;

    // Initial position for East to West path
    int ewPathY = rand() % (height - 3) + 2;
    int prevEwPathY = ewPathY;

    // Create bendy N-S path
    for (int row = 0; row < height; row++) {
        map[row][nsPathX] = path;
        // Randomly decide if the path bends
        if (rand() % 4 == 0) { 
            prevNsPathX = nsPathX;
            // -1 = Move path left, 1 = right, or 0 = stay the same
            nsPathX += rand() % 3 - 1; 
            // Make sure path doesn't go out of bounds if nsPathX < 1 it resets it to 1.
            if (nsPathX < 1) {
                nsPathX = 1;  
            }
            // Make sure path doesn't go out of bounds if greater or equal to width - 1 then resets to width - 2
            if (nsPathX >= width - 1) {
                nsPathX = width - 2;  
            } 
            
            // Makes paths walkable horizontally when there is a bend
            if (prevNsPathX < nsPathX) {
                startX = prevNsPathX;
            } else {
                startX = nsPathX;
            }       
            if (prevNsPathX > nsPathX) {
                endX = prevNsPathX;
            } else {
                endX = nsPathX;
            }
            for (int col = startX; col <= endX; col++) {
                map[row][col] = path;
            }
        }
    }

    // Create bendy E-W path
    for (int x = 0; x < width; x++) {
        map[ewPathY][x] = path;
        // Randomly decide if the path bends
        if (rand() % 4 == 0) { 
            prevEwPathY = ewPathY;
            // -1 = Move path up, 1 = down, or 0 = stay the same
            ewPathY += rand() % 3 - 1; 
            // If ewPathY < 1 it resets it to 1 so it doesn't go out of bounds
            if (ewPathY < 1) {
                ewPathY = 1;  
            }
            // If ewPathY >= height - 1 it resets it to height - 2 so it doesn't go out of bounds
            if (ewPathY >= height - 1) {
                ewPathY = height - 2;  
            }
            
            // Makes paths walkable vertically when there is a bend
            if (prevEwPathY < ewPathY) {
                startY = prevEwPathY;
            } else {
                startY = ewPathY;
            }
            if (prevEwPathY > ewPathY) {
                endY = prevEwPathY;
            } else {
                endY = ewPathY;
            }
            for (int y = startY; y <= endY; y++) {
                map[y][x] = path;
    }

        }
    }
}

void placeBuilding(char map[height][width], char buildingType) {
    int row, col; 
    int placed = 0;
    while (!placed) {
        // Randomly choose a position on the map
        col = rand() % width;
        row = rand() % height;

        // Check if the position is a path and has an adjacent clearing
        if (map[row][col] == PATH) {
            if (row > 0 && map[row-1][col] == CLEARING) {
                map[row-1][col] = buildingType;
                placed = 1;
            } else if (row < height - 1 && map[row+1][col] == CLEARING) {
                map[row+1][col] = buildingType;
                placed = 1;
            } else if (col > 0 && map[row][col-1] == CLEARING) {
                map[row][col-1] = buildingType;
                placed = 1;
            } else if (col < width - 1 && map[row][col+1] == CLEARING) {
                map[row][col+1] = buildingType;
                placed = 1;
            }
        }
    }
}

void addTerrain(char map[height][width], char terrainType, int count) {
    int centerRow, centerCol, radius;
    for (int i = 0; i < count; i++) {
        // Randomly choose a center position for the terrain
        centerCol = rand() % width;
        centerRow = rand() % height;
        // Randomly choose a radius with my preffered range of 3-9
        radius = rand() % 7 + 3;

        //Iterate through grid to get position
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                // Distance from the center
                double distance = sqrt(pow(x - centerCol, 2) + pow(y - centerRow, 2));

                // Check if within radius and not overwriting paths or borders then place terrain accordingly
                if (distance <= radius && map[y][x] != PATH && map[y][x] != BOULDER && map[y][x] != TALL_GRASS) {
                    map[y][x] = terrainType;
                }
            }
        }
    }
}

void addOtherFeatures(char map[height][width]) {
    int col, row;
    // Gets total number of trees and boulders between 10 and 20 to be generated.
    int totalTrees = rand() % 11 + 10;  
    int totalBoulders = rand() % 11 + 10;

    for (int i = 0; i < totalTrees; i++) {
        do {
            // Randomly choose a position on the map
            col = rand() % width;
            row = rand() % height;
        } while (map[row][col] != CLEARING);  // Ensure it's placed on a clearing

        // Place the tree at the chosen position
        map[row][col] = TREE;
    }
    for (int i = 0; i < totalBoulders; i++) {
        do {
            // Randomly choose a position on the map
            col = rand() % width;
            row = rand() % height;
        } while (map[row][col] != CLEARING);  // Ensure it's placed on a clearing

        // Place the boulder at the chosen position
        map[row][col] = BOULDER;
    }
}


void printMap(char map[height][width]) {
    // Print the map
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            printf("%c", map[y][x]); 
        }
        printf("\n"); 
    }
}


int main(){
srand(time(NULL));

// Initialize the map
char map[height][width];
initializeMap(map);

// Create paths
createPath(map, PATH);


// Add terrains
addTerrain(map, TALL_GRASS, 2); 
addTerrain(map, WATER, 1); 

// Add boulders and trees
addOtherFeatures(map);

// Place pokemon center/mart
placeBuilding(map, POKEMON_CENTER);
placeBuilding(map, POKEMART);

// Print the map
printMap(map);

    return 0;
}